<?php $page = "home"; ?> 

test

<?php require_once("includes/top.inc.php"); ?> 




<body>
<div class="gridContainer clearfix">
  		
		<?php require_once("includes/header.inc.php"); ?> 
  
  		<section class="main">
  		  <h2>Welcome!</h2>
  			<figure>
			<img src="baseball.jpg" />
  				<figcaption>
  				  <p>According to Lawson, figcaption is NOT another DIV</p>
  				</figcaption>
  			</figure>
            
            <p>This is a test.</p>
            <p>This is another test.</p>
  		</section>
		
		<?php include_once("includes/sidebar.inc.php"); ?>
		<?php include_once("includes/footer.inc.php"); ?>
        
  </div>
</body>
</html>

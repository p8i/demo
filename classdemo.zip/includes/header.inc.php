<header>
 			 <h1>Demo Widgets</h1>
 	 	 	<nav>
  				<a href="index.php" title="" class="home_lnk">Home</a>
 				<a href="about.php" title="" class="about_lnk">About</a>
  				<a href="products.php" title="" class="products_lnk">Products</a>
 	 			<a href="contact.php" title="" class="contact_lnk">Contact</a>
 		 	</nav>
  		</header>
		
		

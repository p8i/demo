<?php
//sitewide configuration data here
//set local timezone
putenv('TZ=US/Eastern');
//create DB constants
define('HOST', 'localhost');
define('DBNAME', 'mayhem5_classdemo');
define('USER', 'mayhem5_imd410');
define('PASS', 'onlyone12');

//connect to DB
$db = new mysqli(HOST, DBNAME, USER, PASS, DBNAME);

if(mysqli_connecterrno())
{
echo 'Error: Could not connect to database. Please try again later.'
exit(); 
}
?> 